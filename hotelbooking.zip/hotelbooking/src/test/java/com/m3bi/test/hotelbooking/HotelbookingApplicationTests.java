package com.m3bi.test.hotelbooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelbookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
